
  # 웹프로그래밍_기말

  This is a code bundle for 웹프로그래밍_기말. The original project is available at https://www.figma.com/design/EhHEHDNYM9vRvXufzGGrUg/%EC%9B%B9%ED%94%84%EB%A1%9C%EA%B7%B8%EB%9E%98%EB%B0%8D_%EA%B8%B0%EB%A7%90.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  