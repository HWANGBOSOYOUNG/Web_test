import { useState } from "react";
import { Tooltip } from "./ui/tooltip";
import { shaders } from "./util/shaders";
import { ShaderPreviewButton } from "./ShaderPreviewButton";
import { motion, AnimatePresence } from "framer-motion";

interface ShaderSelectorProps {
  selectedShader: number;
  onSelectShader: (id: number) => void;
  onHomeClick: () => void;
}

export const ShaderSelector = ({ selectedShader, onSelectShader, onHomeClick }: ShaderSelectorProps) => {
  const [hoveredShader, setHoveredShader] = useState<number | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleShaderSelect = (id: number) => {
    onSelectShader(id);
    setIsMenuOpen(false); // Close menu after selection
  };

  return (
    <div className="fixed top-2 z-10" style={{ right: '8px' }}>
      <div className="flex flex-row items-center gap-3">
        {/* Shader Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
              className="flex flex-row gap-3"
            >
              {shaders.map((shader) => (
                <Tooltip key={shader.id} content={shader.name} side="left">
                  <div className={`flex flex-col items-center gap-1 ${hoveredShader && hoveredShader !== shader.id ? 'opacity-60' : 'opacity-100'}`}>
                    <ShaderPreviewButton
                      shaderId={shader.id}
                      isSelected={selectedShader === shader.id}
                      onSelect={() => handleShaderSelect(shader.id)}
                      onMouseEnter={() => setHoveredShader(shader.id)}
                      onMouseLeave={() => setHoveredShader(null)}
                    />
                    <span className="text-white text-xs opacity-70 whitespace-nowrap">{shader.name}</span>
                    <span className="text-white text-[10px] opacity-50">click !</span>
                  </div>
                </Tooltip>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Clover Icon Button */}
        <div className="flex flex-col items-center gap-1">
          <button
            onClick={() => {
              if (isMenuOpen) {
                setIsMenuOpen(false);
              } else {
                setIsMenuOpen(true);
              }
            }}
            onDoubleClick={onHomeClick}
            className="text-4xl cursor-pointer hover:scale-110 transition-transform duration-200 bg-white/10 backdrop-blur-sm rounded-full w-14 h-14 flex items-center justify-center"
            aria-label="Toggle shader menu"
            title="Click to open menu, Double-click to go home"
          >
            ♣
          </button>
          <span className="text-white text-xs opacity-70">Home</span>
        </div>
      </div>
    </div>
  );
};