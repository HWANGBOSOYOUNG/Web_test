import { motion } from "framer-motion";
import mainImage from "figma:asset/485c209c72464359a557e4996c424d6f4e70b1d6.png";

export const MainScreen = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen w-full flex items-center justify-center bg-black"
    >
      <div className="relative w-full h-full">
        {/* Desktop: Single image */}
        <img
          src={mainImage}
          alt="Show Me - Music Never Ends"
          className="hidden md:block w-full h-auto object-cover"
        />
        
        {/* Mobile: 3 images stacked vertically */}
        <div className="md:hidden flex flex-col w-full">
          <img
            src={mainImage}
            alt="Show Me - Music Never Ends - Top"
            className="w-full h-auto object-cover"
          />
          <img
            src={mainImage}
            alt="Show Me - Music Never Ends - Middle"
            className="w-full h-auto object-cover"
          />
          <img
            src={mainImage}
            alt="Show Me - Music Never Ends - Bottom"
            className="w-full h-auto object-cover"
          />
        </div>
      </div>
    </motion.div>
  );
};