import { useState, useEffect, useRef } from "react";
import { ShaderCanvas } from "./components/ShaderCanvas";
import { ShaderSelector } from "./components/ShaderSelector";
import { SheetReminderInput } from "./components/SheetReminderInput";
import { useReminderManager } from "./components/ReminderManager";
import { CenterReminderDisplay } from "./components/CenterReminderDisplay";
import { SonnerToastProvider } from "./components/SonnerToastProvider";
import { MainScreen } from "./components/MainScreen";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./components/ui/button";
import "./styles/sonner-fixes.css";
import "./styles/input-fixes.css";
import "./styles/volume-slider.css";

export default function App() {
  const {
    reminders,
    addReminder,
    removeReminder,
    clearAllReminders,
    hasUpcomingReminders,
    markReminderComplete,
  } = useReminderManager();
  const [canvasSize, setCanvasSize] = useState(600);
  const [showInput, setShowInput] = useState(false);
  const [selectedShader, setSelectedShader] = useState(1); // Default to the first shader
  const [isMainScreen, setIsMainScreen] = useState(true); // Start with main screen
  const [isMuted, setIsMuted] = useState(true); // Start muted by default
  const [volume, setVolume] = useState(0.5); // Volume level (0.0 to 1.0)
  const [showVolumeSlider, setShowVolumeSlider] =
    useState(false);
  const [showIntroduction, setShowIntroduction] = useState(false); // Show introduction text
  const audioRef = useRef<HTMLAudioElement>(null);

  // Set dark mode
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  // Adjust canvas size based on window size
  useEffect(() => {
    const handleResize = () => {
      const size =
        Math.min(window.innerWidth, window.innerHeight) * 0.7;
      setCanvasSize(size);
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // Toggle sheet visibility when clicking on shader
  const handleCanvasClick = () => {
    setShowIntroduction(true);
  };

  // Handle shader selection
  const handleSelectShader = (id: number) => {
    setSelectedShader(id);
    setIsMainScreen(false); // Switch to shader screen
    // Store preference in localStorage for persistence across sessions
    localStorage.setItem("selectedShader", id.toString());
  };

  // Handle home button click
  const handleHomeClick = () => {
    setIsMainScreen(true); // Go back to main screen
  };

  // Load shader preference from localStorage on initial load
  useEffect(() => {
    const savedShader = localStorage.getItem("selectedShader");
    if (savedShader) {
      setSelectedShader(parseInt(savedShader, 10));
    }
  }, []);

  // Handle audio mute/unmute
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = isMuted;
      audioRef.current.volume = volume;
      if (!isMuted) {
        // Try to play when unmuted
        audioRef.current.play().catch((error) => {
          console.log("Audio play failed:", error);
        });
      } else {
        // Pause when muted
        audioRef.current.pause();
      }
    }
  }, [isMuted, volume]);

  // Auto-play audio on component mount
  useEffect(() => {
    if (audioRef.current) {
      // Set initial volume
      audioRef.current.volume = volume;
      // Try to autoplay (will be muted initially due to browser policies)
      audioRef.current.play().catch((error) => {
        console.log(
          "Initial audio play failed (expected):",
          error,
        );
      });
    }
  }, []);

  // Toggle mute state
  const toggleMute = () => {
    const newMutedState = !isMuted;
    setIsMuted(newMutedState);

    // Immediately try to play when unmuting
    if (!newMutedState && audioRef.current) {
      audioRef.current.muted = false;
      audioRef.current.play().catch((error) => {
        console.log("Audio play failed:", error);
      });
    }
  };

  // Handle volume change
  const handleVolumeChange = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (newVolume > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  // Check if there are any active reminders
  const activeRemindersExist =
    reminders.filter((r) => !r.completed).length > 0;

  // Check if there are any upcoming reminders (within 5 minutes)
  const upcomingRemindersExist = hasUpcomingReminders();

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative">
      {/* Background Audio */}
      {/* Requested song: https://www.dropbox.com/scl/fi/fjte28pua38r2gjr31v4d/Song.mp3?rlkey=jg6q7z2ki01rrnqg3334fjkd6&st=ni8847n1&dl=0 */}
      <audio ref={audioRef} loop autoPlay>
        <source
          src="https://www.dropbox.com/scl/fi/fjte28pua38r2gjr31v4d/Song.mp3?rlkey=jg6q7z2ki01rrnqg3334fjkd6&st=ni8847n1&raw=1"
          type="audio/mpeg"
        />
        Your browser does not support the audio element.
      </audio>
      
      {/* Sonner Toast Provider */}
      <SonnerToastProvider />

      {/* Audio Control - Fixed position top left corner */}
      <div
        className="fixed top-2 z-50"
        style={{ left: '-20px' }}
        onMouseEnter={() => setShowVolumeSlider(true)}
        onMouseLeave={() => setShowVolumeSlider(false)}
      >
        {/* Mute/Unmute Button with label */}
        <div className="flex flex-col items-center gap-1">
          <button
            onClick={toggleMute}
            className="text-4xl cursor-pointer hover:scale-110 transition-transform duration-200"
            aria-label={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? "🔇" : "🔊"}
          </button>
          <span className="text-white text-xs opacity-70">sound</span>
        </div>

        {/* Volume Slider - Below the emoji */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{
            opacity: showVolumeSlider ? 1 : 0,
            y: showVolumeSlider ? 0 : -10,
          }}
          transition={{ duration: 0.2 }}
          className="flex items-center mt-2"
          style={{
            pointerEvents: showVolumeSlider ? "auto" : "none",
          }}
        >
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={volume}
            onChange={handleVolumeChange}
            className="w-24 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider-thumb"
            style={{
              background: `linear-gradient(to right, #ffffff ${volume * 100}%, #374151 ${volume * 100}%)`,
            }}
          />
          <span className="ml-2 text-white text-sm min-w-[3ch]">
            {Math.round(volume * 100)}%
          </span>
        </motion.div>
      </div>

      {/* Shader Selector - Now positioned fixed on the right */}
      <ShaderSelector
        selectedShader={selectedShader}
        onSelectShader={handleSelectShader}
        onHomeClick={handleHomeClick}
      />

      {/* Student Info - Fixed position bottom right */}
      <div className="fixed bottom-6 right-6 text-white text-right z-50">
        <div className="text-sm opacity-70">황보소영</div>
        <div className="text-sm opacity-70">aisw계열</div>
        <div className="text-sm opacity-70">202578241</div>
      </div>

      {/* Project Title - Fixed position bottom left */}
      <div className="fixed bottom-6 left-6 text-white text-left z-50">
        <div className="text-sm opacity-70">웹프로그래밍 프로젝트</div>
      </div>

      {/* Main Content - Toggle between Main Screen and Shader Screen */}
      <AnimatePresence mode="wait">
        {isMainScreen ? (
          <MainScreen key="main" />
        ) : (
          <div
            key="shader"
            className="relative flex flex-col items-center justify-center"
          >
            {/* Shader Circle */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="relative flex flex-col items-center"
            >
              <ShaderCanvas
                size={canvasSize}
                onClick={handleCanvasClick}
                hasActiveReminders={activeRemindersExist}
                hasUpcomingReminders={upcomingRemindersExist}
                shaderId={selectedShader}
              />

              {/* Center Reminder Display */}
              <CenterReminderDisplay
                reminders={reminders}
                onRemove={removeReminder}
                onComplete={markReminderComplete}
                size={canvasSize}
              />

              {/* Introduction Text Overlay */}
              <AnimatePresence>
                {showIntroduction && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0 flex items-center justify-center z-50"
                    onClick={() => setShowIntroduction(false)}
                  >
                    {/* Backdrop */}
                    <div className="absolute inset-0 bg-black/70 backdrop-blur-sm rounded-full" />
                    
                    {/* Text Content */}
                    <motion.div
                      initial={{ scale: 0.9, y: 20 }}
                      animate={{ scale: 1, y: 0 }}
                      exit={{ scale: 0.9, y: 20 }}
                      transition={{ duration: 0.3 }}
                      className="relative z-10 max-w-md px-8 text-white text-center"
                    >
                      {selectedShader === 1 ? (
                        <>
                          <p className="leading-relaxed opacity-90">
                            성격적으로는 낯가림이 있어 처음에는 다소 까칠하게 보일 수 있지만 객관적으로 상황을 바라보려는 태도에서 비롯된 것입니다. 그러나 가까워진 사람들에게는 책임감을 가지고 잘 챙기며 신뢰를 쌓아가는 성향이 있습니다. 팀 활동이나 협력 과정에서 신뢰를 기반으로 한 관계를 형성하는 데 도움이 된다고 생각합니다.
                          </p>
                          <p className="leading-relaxed opacity-90 mt-4">
                            저는 목표가 없으면 동기부여가 잘 되지 않는다는 단점이 있습니다. 극복하기 위해 스스로 단점을 깨우쳤을 때 작은 목표라도 설정하여 무기력해지지 않게 노력하며 그 과정에서 자기 관리 능력을 키워가고 습니다. 반대로 목표가 생기면 반드시 달성하겠다는 나의 최후의 수를 다 쓰겠다는 강한 의지를 가지고 최우선으로 두고 노력하는 성향이 있습니다. 실제로 학업 과정에서도 꾸준히 특강에 참여하며 장학금을 받은 경험이 있습니다.
                          </p>
                        </>
                      ) : selectedShader === 2 ? (
                        <>
                          <h2 className="opacity-90 mb-4">수상경력</h2>
                          <div className="space-y-3">
                            <div className="leading-relaxed opacity-90">
                              전공탐색포트폴리오
                            </div>
                            <div className="leading-relaxed opacity-90">
                              2025.08.05
                            </div>
                            <div className="leading-relaxed opacity-90">
                              비교과 참여 우수자 장학금-교수학습지원센터
                            </div>
                          </div>
                        </>
                      ) : selectedShader === 3 ? (
                        <div className="max-h-[60vh] overflow-y-auto pr-2">
                          <h2 className="opacity-90 mb-4">교육이수내역</h2>
                          <div className="space-y-5 text-left text-sm">
                            <div className="opacity-90">
                              <div className="mb-1">2025.04.16 - 2025.04.16</div>
                              <div className="mb-1">취업코치의 꿀팁 대방출(스펙부터 AI면접까지) STEP(국민평생직업능력개발)</div>
                              <div className="opacity-75 text-xs">최신 취업트렌드 및 스펙관리, 자기소개서 작성 등 일자리 정보를 알고 희망하는 직무에 지원할 수 있다. AI면접(역량검사) 종류와 특징 및 대응법을 이해하고, 답변전략을 구상할 수 있다.</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.04.16 - 2025.04.16</div>
                              <div className="mb-1">사회초년 취업준비생을 위한 자기소개서 작성법 STEP(국민평생직업능력개발)</div>
                              <div className="opacity-75 text-xs">합격 자기소개서의 공통점이 무엇인지 파악하여 자기소개서를 작성할 수 있다. 자기소개서의 항목을 이해하고, 항목별 답변 포인트를 파악할 수 있다.</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.04.18 - 2025.04.18</div>
                              <div className="mb-1">사회초년 취업준비생을 위한 필수 면접 전략 STEP(국민평생직업능력개발)</div>
                              <div className="opacity-75 text-xs">인성면접/전공 및 직무역량면접/토론면접 등 다양한 유형별 면접방식 이해하고, 자신에게 필요한 면접 준비 능력을 길러, 면접 질문의 의도 파악 및 대응 전략을 수립할 수 있는 역량을 향상시킬 수 있다.</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.05.20 - 2025.05.29</div>
                              <div className="mb-1">Notion(노션) 데이터베이스 중급_Part.1 테이블 컬럼 속성 스킬업클래스</div>
                              <div className="opacity-75 text-xs">12차례에 거친 단계적인 노션 이용법</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.05.20 - 2025.05.27</div>
                              <div className="mb-1">C++프로그래밍 기초 1회 스킬업클래스</div>
                              <div className="opacity-75 text-xs">다른 언어랑 뭐가 다른지부터 vs를 깔고 설치하는 기초적인 부분을 세세히 알려주는 강의</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.05.20 - 2025.05.23</div>
                              <div className="mb-1">C++프로그래밍 기초 2 스킬업클래스</div>
                              <div className="opacity-75 text-xs">c++의 기초 문법을 가르쳐 간단한 실습을 통한 능력 쌓기</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.06.16 - 2025.06.20</div>
                              <div className="mb-1">직무계열별 취업전략(홍보/마케팅) (실시간 온라인) 대학일자리플러스센터</div>
                              <div className="opacity-75 text-xs">(월)직무분석 (화) 직무맞춤형 입사지원서 작성전략 (수) 알짜기업분석 및 기업서치전략 (목) 직무맞춤형 면접 커뮤니케이션 및 답변전략(직무.인성) (금) 직무맞춤형 유형별 면접전략(PT.토론.AI. 역량검사 등)</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.06.25 - 2025.06.27</div>
                              <div className="mb-1">cos pro python (파이썬) 1급 스킬업클래스</div>
                              <div className="opacity-75 text-xs">파이썬 기본부터 문법 쌓기</div>
                            </div>
                            
                            <div className="opacity-90">
                              <div className="mb-1">2025.07.21 - 2025.07.25</div>
                              <div className="mb-1">기초실무역량강화프로그램_컴퓨터활용능력2급 (실시간 온라인) 대학일자리플러스센터</div>
                              <div className="opacity-75 text-xs">컴퓨터 활용능력 자격증 2급 실기 연습</div>
                            </div>
                          </div>
                        </div>
                      ) : selectedShader === 4 ? (
                        <div className="max-h-[60vh] overflow-y-auto pr-2 max-w-2xl">
                          <h2 className="opacity-90 mb-4">1~4학년 로드맵</h2>
                          <table className="w-full border-collapse text-left text-sm">
                            <thead>
                              <tr className="border-b border-white/30">
                                <th className="p-2 opacity-90"></th>
                                <th className="p-2 opacity-90">1학기</th>
                                <th className="p-2 opacity-90">2학기</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr className="border-b border-white/20">
                                <td className="p-2 opacity-90">1학년</td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-2">선택강의를 들을 수 없는 상태(��수강의)</p>
                                  <p className="mb-2">가장 시간이 많을 시간인 만큼 교내 비교과나 학교 프로그램에 참가하여 마일리지나 정보를 얻는다</p>
                                  <p>ex) 잠깐만나Job , 클린코딩, 멘토링(스터디그룹)</p>
                                </td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-2">선택강의를 들을 수 없는 상태(필수강의)</p>
                                  <p className="mb-2">가장 시간이 많을 시간인 만큼 교내 비교과나 학교 프로그램에 참가하여 마일리지나 정보를 얻는다</p>
                                  <p>ex) 잠깐만나Job , 클린코딩, 멘토링(스터디그룹)</p>
                                </td>
                              </tr>
                              <tr className="border-b border-white/20">
                                <td className="p-2 opacity-90">2학년</td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-1">xr콘텐츠입문, 자바 수강</p>
                                  <p className="mb-1">연구회 멘토링 참가</p>
                                  <p className="mb-1">포토폴리오 강화</p>
                                  <p>교외 공모전 참가</p>
                                </td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-1">xr콘텐츠 응용, 고급프로그래밍 수강</p>
                                  <p className="mb-1">연구회 멘토링 참가</p>
                                  <p className="mb-1">포토폴리오 강화</p>
                                  <p className="mb-1">교외 공모전 참가</p>
                                  <p>자격증 준비</p>
                                </td>
                              </tr>
                              <tr className="border-b border-white/20">
                                <td className="p-2 opacity-90">3학년</td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-1">게임프로그래밍, 컴퓨터 네트워크 수강</p>
                                  <p className="mb-1">포토폴리오 강화</p>
                                  <p className="mb-1">교외 공모전 참가</p>
                                  <p className="mb-1">자격증 따기</p>
                                  <p>경진대회</p>
                                </td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-1">ui/ux프로그래밍, 가상/증강현실 수강</p>
                                  <p className="mb-1">포토폴리오 강화</p>
                                  <p className="mb-1">인턴쉽 준비(단기)</p>
                                  <p className="mb-1">자격증 따기</p>
                                  <p>논(계획) 준비</p>
                                </td>
                              </tr>
                              <tr>
                                <td className="p-2 opacity-90">4학년</td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-1">필수 목 이수</p>
                                  <p className="mb-1">포토폴리오 강화</p>
                                  <p className="mb-1">인턴쉽(장기)</p>
                                  <p>논문 준비</p>
                                </td>
                                <td className="p-2 opacity-75 text-xs">
                                  <p className="mb-1">필수 과목 이수</p>
                                  <p className="mb-1">포토폴리오 강화</p>
                                  <p className="mb-1">인턴쉽(장기)</p>
                                  <p>논문</p>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      ) : null}
                      <p className="text-xs mt-6 opacity-60">클릭하여 닫기</p>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>
              
              {/* Click hint below shader circle */}
              <span className="text-white text-[10px] opacity-50 mt-2">클릭하여 열기</span>
            </motion.div>

            {/* Add Reminder Button - Between canvas and clear button */}
            <div className="mt-8 mb-4">
              <Button
                onClick={() => setShowInput(true)}
                className="px-8 py-2 bg-primary/50 backdrop-blur-sm hover:bg-primary/70 rounded-full h-auto min-w-[160px]"
                style={{ opacity: showIntroduction ? 0 : 1, pointerEvents: showIntroduction ? 'none' : 'auto' }}
              >
                오늘의 기억
              </Button>
            </div>

            {/* Clear Reminders Button - Fixed position outside circle */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{
                opacity: activeRemindersExist ? 1 : 0,
              }}
              transition={{ duration: 0.3 }}
              className="absolute bottom-[-70px] left-1/2 transform -translate-x-1/2"
              style={{
                pointerEvents: activeRemindersExist
                  ? "auto"
                  : "none",
              }}
            >
              <Button
                variant="secondary"
                size="sm"
                onClick={clearAllReminders}
                className="px-8 py-2 bg-secondary/30 backdrop-blur-sm hover:bg-secondary/50 rounded-full h-auto min-w-[160px] p-[7px] m-[0px] px-[8px] py-[7px]"
                disabled={!activeRemindersExist}
              >
                Clear Reminders
              </Button>
            </motion.div>

            {/* Sheet for Reminder Input */}
            <SheetReminderInput
              open={showInput}
              onOpenChange={setShowInput}
              onAddReminder={addReminder}
            />
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}